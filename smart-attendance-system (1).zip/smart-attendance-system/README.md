# 🎓 Smart Attendance System

Face-recognition attendance using **Streamlit + OpenCV + DeepFace (pretrained FaceNet512)**, SQLite locally and PostgreSQL online.
It does **not** train a model; it runs pretrained inference only.

## Project structure
```
app.py                       home page
pages/1_Student_Attendance.py   camera/upload -> attendance
pages/2_Admin_Dashboard.py      stats, chart, recent records
pages/3_Student_Management.py   add/edit/deactivate/delete students + faces
pages/4_Attendance_Reports.py   filters, CSV/Excel, manual correction, audit log
config.py database.py auth.py ui.py utils.py
face_recognition_service.py  attendance_service.py  student_service.py  reports.py
scripts/init_db.py           create tables / users
scripts/validate_threshold.py  choose your threshold from real data
tests/                       37 unit tests (no camera/TensorFlow needed)
docs/REPORT.md               report outline, diagrams, viva Q&A
```

## 1. Windows setup (beginner)
1. **Python 3.11** – https://www.python.org/downloads/release/python-3119/ → tick **"Add python.exe to PATH"**. (TensorFlow 2.15 does NOT work on Python 3.12/3.13.)
2. **VS Code** – https://code.visualstudio.com → install the **Python** extension.
3. Extract the ZIP, then in VS Code: *File → Open Folder → smart-attendance-system*. Open *Terminal → New Terminal* (use **Command Prompt**, not PowerShell, or run `Set-ExecutionPolicy -Scope Process Bypass` first).
4. Run these one by one:
```
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```
5. Edit `.env` (open in VS Code): set `ADMIN_PASSWORD` (min 8 chars). Optional: generate `EMBEDDING_KEY`:
```
python -c "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())"
```
6. Initialize DB and start:
```
python scripts/init_db.py
streamlit run app.py
```
7. Open **http://localhost:8501**. Log in from the sidebar (username/password from `.env`).

First recognition downloads the FaceNet512 weights (~90 MB) – needs internet once.

### Troubleshooting
| Problem | Fix |
|---|---|
| `pip` fails on tensorflow | You have Python 3.12+. Install 3.11 and recreate `.venv`. |
| `.venv\Scripts\activate` blocked | Use Command Prompt, or PowerShell: `Set-ExecutionPolicy -Scope Process Bypass` |
| Camera is black / no prompt | Click the 🔒 icon in the address bar → allow Camera; close Zoom/Teams; try Chrome. |
| "Face model could not be loaded" | Re-run `pip install -r requirements.txt`; check internet for first weight download. |
| `ModuleNotFoundError` | Venv not active – run `.venv\Scripts\activate` again. |

## 2. Run the tests
```
python -m unittest discover -s tests -t . -v
```

## 3. Choose the recognition threshold (important!)
`DISTANCE_THRESHOLD=0.30` (cosine, Facenet512) is only DeepFace's default. Validate it:
1. Make folder `validation/<person>/` with 3+ photos for 5–10 people (**do not commit it**).
2. `python scripts/validate_threshold.py validation`
3. Read the FAR (wrong person accepted) / FRR (right person rejected) table, put the chosen value in `.env`.
Prefer low FAR for attendance. Re-validate if you change the camera or lighting.

## 4. Phone access
- **Public HTTPS (recommended):** deploy (section 5) and open the URL on Android Chrome → allow camera.
- **Same Wi-Fi:** `streamlit run app.py --server.address 0.0.0.0`, find the laptop IP (`ipconfig`), open `http://<IP>:8501`, allow Windows Firewall for Python. `localhost` on the phone is the PHONE, not your laptop.
  Browsers block the camera on plain `http://` LAN addresses. Either use **Upload photo → take photo** (works over HTTP), or get a temporary HTTPS link with Cloudflare Tunnel: `cloudflared tunnel --url http://localhost:8501`.

## 5. GitHub + Streamlit Community Cloud
1. Create account at github.com → **New repository** `smart-attendance-system` (Private recommended).
2. In the project folder:
```
git init
git add .
git status        (confirm .env, .venv, data/*.db are NOT listed)
git commit -m "Smart Attendance System"
git branch -M main
git remote add origin https://github.com/<you>/smart-attendance-system.git
git push -u origin main
```
3. **Database:** Streamlit Cloud files are temporary, so create a free PostgreSQL (e.g. Supabase or Neon) and copy its connection string (`postgresql://user:pass@host:5432/db?sslmode=require`).
4. At share.streamlit.io → **Create app** → pick repo, branch `main`, file `app.py` → **Advanced settings**: choose **Python 3.11** and paste secrets:
```
DATABASE_URL = "postgresql://..."
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "a-strong-password"
EMBEDDING_KEY = "<generated key>"
TIMEZONE = "Asia/Kolkata"
```
5. Deploy, wait for the build, open the **URL Streamlit shows you** and test login, registration and attendance. Copy that real URL into your report.
6. ⚠️ TensorFlow + FaceNet is heavy; the free tier (~1 GB RAM) may run out of memory. If it crashes, demo from your laptop with Cloudflare Tunnel, or deploy on a host with more RAM.

## 6. Test checklist
Executed in development (automated, passing): registration & validation, duplicate roll, consent, duplicate attendance (app + DB constraint), date/time, future-date rejection, matching/unknown/ambiguous on synthetic embeddings, embedding encryption, image validation (garbage/tiny/dark), authorization, password hashing, CSV/Excel export, cascade delete.
**Manual, you must verify:** real face detection and recognition with your classmates, unknown-face rejection, camera on laptop and Android, Streamlit pages visually, PostgreSQL connection, cloud deployment, data persistence after redeploy.

## 7. Privacy, security, limits
- Passwords: scrypt hashes. Secrets only in `.env` / Streamlit secrets (git-ignored).
- Only embeddings are stored (no face photos); optionally Fernet-encrypted. Consent checkbox is mandatory; admin can delete a student and all data; teachers can delete face data.
- No liveness / anti-spoofing: a photo of a student can fool it. Recognition can be wrong; keep manual attendance.
- Login lockout is per browser session only (not a full brute-force defence).
- Changing `MODEL_NAME` requires re-registering faces (embeddings are model-specific).
