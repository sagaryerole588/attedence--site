"""Student and face-embedding management (all writes are permission-checked)."""
from __future__ import annotations

import numpy as np
import pandas as pd

import config
import database
from auth import ensure_permission
from face_recognition_service import deserialize_embedding, serialize_embedding
from utils import clean_text, validate_email, validate_roll_no

COLUMNS = ["id", "roll_no", "name", "class_name", "department", "email", "phone",
           "is_active", "consent_given", "faces"]


def add_student(actor: dict, roll_no: str, name: str, class_name: str, department: str,
                email: str = "", phone: str = "", consent: bool = False) -> int:
    ensure_permission(actor, "manage_students")
    if not consent:
        raise ValueError("Student consent for face data is required.")
    roll_no = validate_roll_no(roll_no)
    name = clean_text(name, "Name")
    class_name = clean_text(class_name, "Class", 40)
    department = clean_text(department, "Department", 60)
    email = validate_email(email)
    phone = clean_text(phone, "Phone", 20, required=False)
    with database.get_conn() as conn:
        try:
            sid = conn.insert(
                "INSERT INTO students (roll_no, name, class_name, department, email, phone, consent_given,"
                " consent_at, created_at) VALUES (?,?,?,?,?,?,1,?,?)",
                (roll_no, name, class_name, department, email, phone, database.now_iso(), database.now_iso()),
            )
        except database.IntegrityViolation:
            raise ValueError(f"Roll number {roll_no} already exists.") from None
        database.log_action(conn, actor, "add_student", roll_no)
        return sid


def update_student(actor: dict, student_id: int, name: str, class_name: str, department: str,
                   email: str = "", phone: str = "") -> None:
    ensure_permission(actor, "manage_students")
    with database.get_conn() as conn:
        conn.execute(
            "UPDATE students SET name=?, class_name=?, department=?, email=?, phone=? WHERE id=?",
            (clean_text(name, "Name"), clean_text(class_name, "Class", 40),
             clean_text(department, "Department", 60), validate_email(email),
             clean_text(phone, "Phone", 20, required=False), student_id),
        )
        database.log_action(conn, actor, "update_student", str(student_id))


def set_active(actor: dict, student_id: int, active: bool) -> None:
    ensure_permission(actor, "manage_students")
    with database.get_conn() as conn:
        conn.execute("UPDATE students SET is_active=? WHERE id=?", (1 if active else 0, student_id))
        database.log_action(conn, actor, "activate_student" if active else "deactivate_student", str(student_id))


def delete_student(actor: dict, student_id: int) -> None:
    """Admin only. Removes the student, face data AND attendance rows (right to erasure)."""
    ensure_permission(actor, "delete_student")
    with database.get_conn() as conn:
        row = conn.one("SELECT roll_no FROM students WHERE id=?", (student_id,))
        conn.execute("DELETE FROM students WHERE id=?", (student_id,))
        database.log_action(conn, actor, "delete_student", row["roll_no"] if row else str(student_id))


def add_face(actor: dict, student_id: int, embedding: np.ndarray) -> None:
    ensure_permission(actor, "register_face")
    with database.get_conn() as conn:
        conn.execute(
            "INSERT INTO face_embeddings (student_id, embedding, model_name, created_at) VALUES (?,?,?,?)",
            (student_id, serialize_embedding(embedding), config.MODEL_NAME, database.now_iso()),
        )
        database.log_action(conn, actor, "register_face", str(student_id))


def delete_faces(actor: dict, student_id: int) -> None:
    ensure_permission(actor, "register_face")
    with database.get_conn() as conn:
        conn.execute("DELETE FROM face_embeddings WHERE student_id=?", (student_id,))
        database.log_action(conn, actor, "delete_faces", str(student_id))


def load_gallery() -> list[tuple[int, np.ndarray]]:
    """Embeddings of ACTIVE students registered with the current model."""
    with database.get_conn() as conn:
        rows = conn.rows(
            "SELECT f.student_id, f.embedding FROM face_embeddings f JOIN students s ON s.id=f.student_id"
            " WHERE s.is_active=1 AND f.model_name=?", (config.MODEL_NAME,))
    return [(r["student_id"], deserialize_embedding(r["embedding"])) for r in rows]


def get_student(student_id: int) -> dict | None:
    with database.get_conn() as conn:
        return conn.one("SELECT * FROM students WHERE id=?", (student_id,))


def list_students(search: str = "", class_name: str | None = None, department: str | None = None,
                  include_inactive: bool = True) -> pd.DataFrame:
    sql = ("SELECT s.id, s.roll_no, s.name, s.class_name, s.department, s.email, s.phone, s.is_active,"
           " s.consent_given, (SELECT COUNT(*) FROM face_embeddings f WHERE f.student_id=s.id) AS faces"
           " FROM students s WHERE 1=1")
    params: list = []
    if search:
        sql += " AND (LOWER(s.name) LIKE ? OR LOWER(s.roll_no) LIKE ?)"
        like = f"%{search.strip().lower()}%"
        params += [like, like]
    if class_name:
        sql += " AND s.class_name=?"; params.append(class_name)
    if department:
        sql += " AND s.department=?"; params.append(department)
    if not include_inactive:
        sql += " AND s.is_active=1"
    sql += " ORDER BY s.roll_no"
    with database.get_conn() as conn:
        rows = conn.rows(sql, tuple(params))
    return pd.DataFrame(rows, columns=COLUMNS)


def distinct_values(column: str) -> list[str]:
    if column not in ("class_name", "department"):
        raise ValueError("Invalid column")
    with database.get_conn() as conn:
        return [r[column] for r in conn.rows(f"SELECT DISTINCT {column} FROM students ORDER BY {column}")]
