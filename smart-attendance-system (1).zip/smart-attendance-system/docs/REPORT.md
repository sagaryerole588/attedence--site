# Smart Attendance System – Project Report Outline

1. **Abstract** – A web-based attendance system that detects a face with OpenCV, converts it to a 512-D embedding with a pretrained FaceNet512 (DeepFace), matches it to registered students using cosine distance and records attendance in a database. Teachers manage students and reports.
2. **Introduction** – Manual roll-call wastes lecture time and allows proxy attendance.
3. **Problem statement** – Provide fast, contactless, auditable attendance with minimal hardware.
4. **Objectives** – Automate attendance; prevent duplicates; admin dashboard; reports; works on laptop and phone; protect privacy.
5. **Existing system & limitations** – Paper/roll-call (slow, proxies), RFID/biometric devices (cost, queues, hygiene).
6. **Proposed system** – Streamlit web app, pretrained face model, SQL database, role-based admin.
7. **Architecture** – see diagram A.
8. **Hardware/Software** – Laptop/phone with camera, 8 GB RAM recommended; Python 3.11, Streamlit, OpenCV, DeepFace/TensorFlow, SQLite/PostgreSQL, Pandas.
9. **ML methodology** – Detection → alignment → embedding (pretrained, no training) → cosine distance → threshold + ambiguity margin. Threshold validated with genuine/impostor pairs (FAR/FRR).
10. **Database design** – see ER diagram C.
11. **Implementation** – modules listed in README.
12. **Testing & results** – automated tests (37) + your manual results table (accuracy on your own class sample: fill after testing).
13. **Advantages & limitations** – Fast, contactless, cheap / spoofing risk, lighting & pose sensitivity, bias risks, privacy concerns.
14. **Future enhancements** – Liveness detection, multi-session timetable, notifications, better detectors (RetinaFace), mobile app.
15. **Conclusion** – Working prototype demonstrates pretrained face recognition for attendance.
16. **References** – DeepFace (Serengil & Ozpinar), FaceNet (Schroff et al., 2015), OpenCV docs, Streamlit docs.

## Diagram A – Architecture
```mermaid
flowchart LR
  P[Phone / Laptop browser] -->|HTTPS| S[Streamlit app]
  S --> V[Image validation]
  V --> F[OpenCV face detection + align]
  F --> E[FaceNet512 embedding]
  E --> M[Cosine match + threshold]
  M --> D[(SQLite / PostgreSQL)]
  S --> A[Auth + roles] --> D
  D --> R[Reports CSV / Excel]
```

## Diagram B – Workflow
```mermaid
flowchart TD
  A[Capture/upload] --> B{Valid, bright, sharp?}
  B -- no --> X[Show error]
  B -- yes --> C{Exactly one face?}
  C -- no --> X
  C -- yes --> D[Embedding]
  D --> E{Distance <= threshold?}
  E -- no --> U[Unknown: manual fallback]
  E -- yes --> G{Runner-up too close?}
  G -- yes --> U
  G -- no --> H{Already marked today?}
  H -- yes --> I[Show 'already recorded']
  H -- no --> J[Save date+time] --> K[Success message]
```

## Diagram C – ER diagram
```mermaid
erDiagram
  USERS ||--o{ ATTENDANCE : marks
  USERS ||--o{ AUDIT_LOGS : performs
  STUDENTS ||--o{ FACE_EMBEDDINGS : has
  STUDENTS ||--o{ ATTENDANCE : has
  STUDENTS { int id PK  text roll_no UK  text name  text class_name  text department  int is_active  int consent_given }
  FACE_EMBEDDINGS { int id PK  int student_id FK  blob embedding  text model_name }
  ATTENDANCE { int id PK  int student_id FK  text attendance_date  text attendance_time  text session_id  text status  text method  int marked_by FK }
  USERS { int id PK  text username UK  text password_hash  text role }
  AUDIT_LOGS { int id PK  int user_id FK  text action  text details }
```
Unique constraint: (student_id, attendance_date, session_id).

## Viva questions and answers
1. **Detection vs recognition?** Detection finds where a face is; recognition decides whose face it is.
2. **What is an embedding?** A fixed-length vector (512 numbers) produced by a neural network so that images of the same person are close together.
3. **Verification vs identification?** Verification = 1:1 "same person?"; identification = 1:N "who is it?". We do 1:N then apply a verification threshold.
4. **Did you train a model?** No. We use pretrained FaceNet512 inference; only the threshold/settings are tuned.
5. **Why cosine distance?** It compares direction of vectors, robust to magnitude; DeepFace recommends it for Facenet512.
6. **How did you choose the threshold?** Measure genuine and impostor distances on our class data and pick the value with low false accepts (scripts/validate_threshold.py).
7. **What are FAR and FRR?** False accept rate (wrong person accepted) and false reject rate (right person rejected); lowering the threshold lowers FAR but raises FRR.
8. **How do you stop duplicates?** App check plus a database UNIQUE(student_id, date, session_id) constraint.
9. **How is security handled?** scrypt-hashed passwords, role checks in service functions, secrets in env, validated uploads, encrypted embeddings, audit log.
10. **Can it be fooled by a photo?** Yes; there is no liveness detection. Future work: blink/depth checks.
11. **Why store embeddings, not photos?** Less sensitive, faster matching, smaller storage; embeddings can still be personal data so they are protected.
12. **Why PostgreSQL online?** Cloud app files are temporary; a managed database persists data.
13. **Why HTTPS for phone camera?** Browsers expose the camera only on secure origins.
14. **What if the face is not recognized?** Teacher manual attendance with reason, logged in the audit table.
15. **Ethical concerns?** Consent, bias across skin tones/lighting, data retention and deletion rights.
