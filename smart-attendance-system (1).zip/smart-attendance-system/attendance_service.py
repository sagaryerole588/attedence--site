"""Attendance rules: one record per student, date and session."""
from __future__ import annotations

from datetime import date as date_cls

import pandas as pd

import config
import database
from auth import ensure_permission
from utils import now_local

RECORD_COLUMNS = ["Date", "Time", "Roll No", "Name", "Class", "Department",
                  "Status", "Method", "Session", "Marked By"]


def _validate_date(d: str) -> str:
    try:
        parsed = date_cls.fromisoformat(d)
    except (TypeError, ValueError):
        raise ValueError("Date must be YYYY-MM-DD.") from None
    if parsed > now_local().date():
        raise ValueError("Attendance cannot be recorded for a future date.")
    return parsed.isoformat()


def mark_attendance(student_id: int, method: str = "face", status: str = "Present",
                    session_id: str = config.DEFAULT_SESSION, marked_by: dict | None = None,
                    date: str | None = None, time: str | None = None) -> tuple[str, str]:
    """Returns ('recorded'|'duplicate'|'inactive'|'not_found', message)."""
    if status not in ("Present", "Absent") or method not in ("face", "manual"):
        raise ValueError("Invalid status or method.")
    if method == "manual":
        ensure_permission(marked_by, "mark_attendance")
    now = now_local()
    date = _validate_date(date or now.strftime("%Y-%m-%d"))
    time = time or now.strftime("%H:%M:%S")
    with database.get_conn() as conn:
        student = conn.one("SELECT id, name, is_active FROM students WHERE id=?", (student_id,))
        if not student:
            return "not_found", "Student not found."
        if not student["is_active"]:
            return "inactive", "This student is deactivated."
        if conn.one("SELECT id FROM attendance WHERE student_id=? AND attendance_date=? AND session_id=?",
                    (student_id, date, session_id)):
            return "duplicate", f"Attendance already recorded for {student['name']} on {date}."
        try:
            conn.insert(
                "INSERT INTO attendance (student_id, attendance_date, attendance_time, session_id, status,"
                " method, marked_by, created_at) VALUES (?,?,?,?,?,?,?,?)",
                (student_id, date, time, session_id, status, method,
                 marked_by["id"] if marked_by else None, database.now_iso()))
        except database.IntegrityViolation:  # race condition safety net
            return "duplicate", f"Attendance already recorded for {student['name']} on {date}."
        if method == "manual":
            database.log_action(conn, marked_by, "manual_attendance", str(student_id), f"{date} {status}")
    return "recorded", f"Attendance recorded for {student['name']} at {time}."


def correct_attendance(actor: dict, student_id: int, date: str, status: str, reason: str,
                       session_id: str = config.DEFAULT_SESSION) -> str:
    """Change (or create) a record by hand; the old value and the reason go to the audit log."""
    ensure_permission(actor, "correct_attendance")
    if status not in ("Present", "Absent"):
        raise ValueError("Invalid status.")
    if not (reason or "").strip():
        raise ValueError("A reason is required for corrections.")
    date = _validate_date(date)
    now = now_local()
    with database.get_conn() as conn:
        if not conn.one("SELECT id FROM students WHERE id=?", (student_id,)):
            raise ValueError("Student not found.")
        old = conn.one("SELECT id, status FROM attendance WHERE student_id=? AND attendance_date=? AND session_id=?",
                       (student_id, date, session_id))
        if old:
            conn.execute("UPDATE attendance SET status=?, method='manual', marked_by=?, attendance_time=? WHERE id=?",
                         (status, actor["id"], now.strftime("%H:%M:%S"), old["id"]))
            msg = f"{old['status']} -> {status}"
        else:
            conn.insert(
                "INSERT INTO attendance (student_id, attendance_date, attendance_time, session_id, status,"
                " method, marked_by, created_at) VALUES (?,?,?,?,?,'manual',?,?)",
                (student_id, date, now.strftime("%H:%M:%S"), session_id, status, actor["id"], database.now_iso()))
            msg = f"new -> {status}"
        database.log_action(conn, actor, "correct_attendance", str(student_id), f"{date}: {msg}. Reason: {reason.strip()}")
    return msg


def _filters(class_name, department, search, params):
    sql = ""
    if class_name:
        sql += " AND s.class_name=?"; params.append(class_name)
    if department:
        sql += " AND s.department=?"; params.append(department)
    if search:
        sql += " AND (LOWER(s.name) LIKE ? OR LOWER(s.roll_no) LIKE ?)"
        like = f"%{search.strip().lower()}%"
        params += [like, like]
    return sql


def attendance_records(start: str, end: str, class_name=None, department=None, search="") -> pd.DataFrame:
    params: list = [start, end]
    sql = ("SELECT a.attendance_date, a.attendance_time, s.roll_no, s.name, s.class_name, s.department,"
           " a.status, a.method, a.session_id, u.username AS marked_by"
           " FROM attendance a JOIN students s ON s.id=a.student_id LEFT JOIN users u ON u.id=a.marked_by"
           " WHERE a.attendance_date BETWEEN ? AND ?")
    sql += _filters(class_name, department, search, params) + " ORDER BY a.attendance_date DESC, a.attendance_time DESC"
    with database.get_conn() as conn:
        rows = conn.rows(sql, tuple(params))
    df = pd.DataFrame([list(r.values()) for r in rows], columns=RECORD_COLUMNS)
    df["Marked By"] = df["Marked By"].fillna("-")
    return df


def daily_status(date: str, class_name=None, department=None, search="",
                 session_id: str = config.DEFAULT_SESSION) -> pd.DataFrame:
    params: list = [date, session_id]
    sql = ("SELECT s.id AS student_id, s.roll_no, s.name, s.class_name, s.department,"
           " a.status, a.attendance_time, a.method FROM students s"
           " LEFT JOIN attendance a ON a.student_id=s.id AND a.attendance_date=? AND a.session_id=?"
           " WHERE s.is_active=1")
    sql += _filters(class_name, department, search, params) + " ORDER BY s.roll_no"
    with database.get_conn() as conn:
        rows = conn.rows(sql, tuple(params))
    df = pd.DataFrame(rows, columns=["student_id", "roll_no", "name", "class_name", "department",
                                     "status", "attendance_time", "method"])
    df["status"] = df["status"].where(df["status"] == "Present", "Absent")
    return df


def daily_summary(date: str, class_name=None, department=None) -> dict:
    df = daily_status(date, class_name, department)
    total = len(df)
    present = int((df["status"] == "Present").sum())
    return {"total": total, "present": present, "absent": total - present,
            "percent": round(100 * present / total, 1) if total else 0.0}


def student_percentages(start: str, end: str, class_name=None, department=None) -> pd.DataFrame:
    """Percentage = days present / sessions held (days with at least one record) in the range."""
    with database.get_conn() as conn:
        held = conn.one("SELECT COUNT(*) AS n FROM (SELECT DISTINCT attendance_date, session_id FROM attendance"
                        " WHERE attendance_date BETWEEN ? AND ?) t", (start, end))["n"]
        params: list = [start, end]
        sql = ("SELECT s.roll_no, s.name, s.class_name, s.department,"
               " SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS present_days"
               " FROM students s LEFT JOIN attendance a ON a.student_id=s.id"
               " AND a.attendance_date BETWEEN ? AND ? WHERE s.is_active=1")
        sql += _filters(class_name, department, "", params) + " GROUP BY s.id, s.roll_no, s.name, s.class_name, s.department ORDER BY s.roll_no"
        rows = conn.rows(sql, tuple(params))
    df = pd.DataFrame(rows, columns=["roll_no", "name", "class_name", "department", "present_days"])
    df["present_days"] = df["present_days"].fillna(0).astype(int)
    df["sessions_held"] = held
    df["percentage"] = (df["present_days"] * 100 / held).round(1) if held else 0.0
    return df


def date_series(start: str, end: str, class_name=None, department=None) -> pd.DataFrame:
    params: list = [start, end]
    sql = ("SELECT a.attendance_date AS date, COUNT(*) AS present FROM attendance a"
           " JOIN students s ON s.id=a.student_id WHERE a.status='Present' AND a.attendance_date BETWEEN ? AND ?")
    sql += _filters(class_name, department, "", params) + " GROUP BY a.attendance_date ORDER BY a.attendance_date"
    with database.get_conn() as conn:
        rows = conn.rows(sql, tuple(params))
    return pd.DataFrame(rows, columns=["date", "present"])


def audit_log(limit: int = 200) -> pd.DataFrame:
    with database.get_conn() as conn:
        rows = conn.rows("SELECT created_at, username, action, target, details FROM audit_logs"
                         " ORDER BY id DESC LIMIT ?", (limit,))
    return pd.DataFrame(rows, columns=["created_at", "username", "action", "target", "details"])


def process_attendance_image(data: bytes, filename: str | None = None) -> dict:
    """Full ML workflow for the student page. Returns {'level','message','student','distance'}."""
    from face_recognition_service import extract_embedding, find_match
    from student_service import get_student, load_gallery
    from utils import ImageValidationError, check_quality, load_image

    try:
        bgr = load_image(data, filename)
        check_quality(bgr)
    except ImageValidationError as exc:
        return {"level": "error", "message": str(exc)}

    emb = extract_embedding(bgr)
    if emb.status != "ok":
        return {"level": "error", "message": emb.message}

    match = find_match(emb.embedding, load_gallery())
    if match.status != "matched":
        level = "warning" if match.status in ("unknown", "ambiguous") else "error"
        return {"level": level, "message": match.message, "distance": match.distance}

    student = get_student(match.student_id)
    status, msg = mark_attendance(match.student_id, method="face")
    level = {"recorded": "success", "duplicate": "info"}.get(status, "error")
    return {"level": level, "message": msg, "student": student, "distance": match.distance}
