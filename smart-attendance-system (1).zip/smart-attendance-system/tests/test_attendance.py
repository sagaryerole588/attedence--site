import unittest
from datetime import timedelta

from tests.base import DBTestCase
import attendance_service as att
import database
from utils import now_local, today_str


class AttendanceTests(DBTestCase):
    def test_marks_with_date_and_time(self):
        sid = self.new_student()
        status, _ = att.mark_attendance(sid, time="09:15:00")
        self.assertEqual(status, "recorded")
        df = att.attendance_records(today_str(), today_str())
        self.assertEqual(df.iloc[0]["Time"], "09:15:00")
        self.assertEqual(df.iloc[0]["Date"], today_str())

    def test_duplicate_prevented(self):
        sid = self.new_student()
        self.assertEqual(att.mark_attendance(sid)[0], "recorded")
        self.assertEqual(att.mark_attendance(sid)[0], "duplicate")
        self.assertEqual(len(att.attendance_records(today_str(), today_str())), 1)

    def test_db_unique_constraint(self):
        sid = self.new_student()
        att.mark_attendance(sid)
        with self.assertRaises(database.IntegrityViolation):
            with database.get_conn() as c:
                c.execute("INSERT INTO attendance (student_id, attendance_date, attendance_time, session_id, status,"
                          " method, created_at) VALUES (?,?,?,?,?,?,?)",
                          (sid, today_str(), "10:00:00", "DAILY", "Present", "face", "x"))

    def test_different_session_allowed(self):
        sid = self.new_student()
        self.assertEqual(att.mark_attendance(sid, session_id="P1")[0], "recorded")
        self.assertEqual(att.mark_attendance(sid, session_id="P2")[0], "recorded")

    def test_inactive_student_rejected(self):
        import student_service as ss
        sid = self.new_student()
        ss.set_active(self.teacher, sid, False)
        self.assertEqual(att.mark_attendance(sid)[0], "inactive")

    def test_future_date_rejected(self):
        sid = self.new_student()
        future = (now_local() + timedelta(days=3)).strftime("%Y-%m-%d")
        with self.assertRaises(ValueError):
            att.mark_attendance(sid, date=future)

    def test_summary_present_absent_percent(self):
        a, b = self.new_student("CE001", "A"), self.new_student("CE002", "B")
        att.mark_attendance(a)
        s = att.daily_summary(today_str())
        self.assertEqual((s["total"], s["present"], s["absent"], s["percent"]), (2, 1, 1, 50.0))
        daily = att.daily_status(today_str())
        self.assertEqual(daily.set_index("roll_no").loc["CE002", "status"], "Absent")

    def test_correction_is_audited(self):
        sid = self.new_student()
        att.mark_attendance(sid)
        att.correct_attendance(self.teacher, sid, today_str(), "Absent", "Marked by mistake")
        df = att.attendance_records(today_str(), today_str())
        self.assertEqual(df.iloc[0]["Status"], "Absent")
        self.assertEqual(df.iloc[0]["Marked By"], "teach")
        log = att.audit_log()
        self.assertTrue(any("Marked by mistake" in str(d) for d in log["details"]))

    def test_correction_needs_reason(self):
        sid = self.new_student()
        with self.assertRaises(ValueError):
            att.correct_attendance(self.teacher, sid, today_str(), "Present", "  ")

    def test_percentages(self):
        sid = self.new_student()
        att.mark_attendance(sid)
        pct = att.student_percentages(today_str(), today_str())
        self.assertEqual(pct.iloc[0]["percentage"], 100.0)


if __name__ == "__main__":
    unittest.main()
