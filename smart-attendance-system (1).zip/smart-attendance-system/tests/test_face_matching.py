import unittest

import numpy as np

import config
import face_recognition_service as frs
from utils import ImageValidationError, load_image


def unit(seed, dim=512):
    v = np.random.default_rng(seed).normal(size=dim)
    return (v / np.linalg.norm(v)).astype(np.float32)


class MatchingTests(unittest.TestCase):
    def test_correct_match(self):
        a, b = unit(1), unit(2)
        noisy = a + 0.05 * unit(9)
        r = frs.find_match(noisy, [(1, a), (2, b)])
        self.assertEqual((r.status, r.student_id), ("matched", 1))

    def test_unknown_rejected(self):
        r = frs.find_match(unit(50), [(1, unit(1)), (2, unit(2))])
        self.assertEqual(r.status, "unknown")

    def test_ambiguous_rejected(self):
        a = unit(1)
        twin = a + 0.01 * unit(3)  # two students with almost identical embeddings
        r = frs.find_match(a, [(1, a), (2, twin)])
        self.assertEqual(r.status, "ambiguous")

    def test_empty_gallery(self):
        self.assertEqual(frs.find_match(unit(1), []).status, "empty_gallery")

    def test_multiple_samples_use_best(self):
        a = unit(1)
        r = frs.find_match(a, [(1, unit(7)), (1, a), (2, unit(2))])
        self.assertEqual(r.student_id, 1)

    def test_serialization_roundtrip_plain(self):
        old = config.EMBEDDING_KEY; config.EMBEDDING_KEY = None
        try:
            v = unit(5)
            np.testing.assert_allclose(frs.deserialize_embedding(frs.serialize_embedding(v)), v)
        finally:
            config.EMBEDDING_KEY = old

    def test_serialization_roundtrip_encrypted(self):
        from cryptography.fernet import Fernet
        old = config.EMBEDDING_KEY; config.EMBEDDING_KEY = Fernet.generate_key().decode()
        try:
            v = unit(5)
            blob = frs.serialize_embedding(v)
            self.assertTrue(blob.startswith(b"E"))
            np.testing.assert_allclose(frs.deserialize_embedding(blob), v)
        finally:
            config.EMBEDDING_KEY = old


class ImageValidationTests(unittest.TestCase):
    def test_garbage_rejected(self):
        with self.assertRaises(ImageValidationError):
            load_image(b"not an image")

    def test_empty_rejected(self):
        with self.assertRaises(ImageValidationError):
            load_image(b"")

    def test_bad_extension_rejected(self):
        with self.assertRaises(ImageValidationError):
            load_image(b"x", "evil.exe")

    def test_tiny_image_rejected(self):
        import io
        from PIL import Image
        buf = io.BytesIO(); Image.new("RGB", (50, 50)).save(buf, "PNG")
        with self.assertRaises(ImageValidationError):
            load_image(buf.getvalue())

    def test_dark_image_rejected(self):
        import io
        from PIL import Image
        from utils import check_quality
        buf = io.BytesIO(); Image.new("RGB", (300, 300), (5, 5, 5)).save(buf, "PNG")
        with self.assertRaises(ImageValidationError):
            check_quality(load_image(buf.getvalue()))


if __name__ == "__main__":
    unittest.main()
