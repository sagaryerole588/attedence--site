import unittest

from tests.base import DBTestCase
import auth
import attendance_service as att
import student_service as ss
from utils import today_str


class AuthorizationTests(DBTestCase):
    def test_password_hash_not_plaintext_and_verifies(self):
        h = auth.hash_password("Secret123")
        self.assertNotIn("Secret123", h)
        self.assertTrue(auth.verify_password("Secret123", h))
        self.assertFalse(auth.verify_password("wrong", h))

    def test_login_success_and_failure(self):
        self.assertEqual(auth.authenticate("admin", "AdminPass123")["role"], "admin")
        self.assertIsNone(auth.authenticate("admin", "bad"))
        self.assertIsNone(auth.authenticate("nobody", "x"))

    def test_short_password_rejected(self):
        with self.assertRaises(ValueError):
            auth.create_user("x", "short", "teacher")

    def test_anonymous_cannot_modify(self):
        with self.assertRaises(PermissionError):
            ss.add_student(None, "CE009", "X", "TE-A", "CE", consent=True)
        sid = self.new_student()
        with self.assertRaises(PermissionError):
            att.mark_attendance(sid, method="manual", marked_by=None)
        with self.assertRaises(PermissionError):
            att.correct_attendance(None, sid, today_str(), "Present", "x")

    def test_teacher_cannot_delete_student(self):
        sid = self.new_student()
        with self.assertRaises(PermissionError):
            ss.delete_student(self.teacher, sid)
        ss.delete_student(self.admin, sid)  # admin can

    def test_teacher_cannot_manage_users_or_audit(self):
        self.assertFalse(auth.can(self.teacher, "manage_users"))
        self.assertFalse(auth.can(self.teacher, "view_audit_log"))
        self.assertTrue(auth.can(self.admin, "view_audit_log"))

    def test_bootstrap_admin_only_when_empty(self):
        self.assertFalse(auth.bootstrap_admin())  # users already exist


if __name__ == "__main__":
    unittest.main()
