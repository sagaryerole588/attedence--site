import io
import unittest

import pandas as pd

from tests.base import DBTestCase
import attendance_service as att
import reports
from utils import today_str


class ReportTests(DBTestCase):
    def test_csv_and_excel_export(self):
        sid = self.new_student()
        att.mark_attendance(sid)
        sheets = reports.range_report(today_str(), today_str())
        csv = reports.to_csv_bytes(sheets["Records"]).decode("utf-8-sig")
        self.assertIn("CE001", csv)
        xlsx = reports.to_excel_bytes(sheets)
        back = pd.read_excel(io.BytesIO(xlsx), sheet_name=None)
        self.assertEqual(set(back), {"Records", "Percentages"})
        self.assertEqual(back["Records"].iloc[0]["Roll No"], "CE001")


if __name__ == "__main__":
    unittest.main()
