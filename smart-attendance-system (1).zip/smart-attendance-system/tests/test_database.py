import unittest

from tests.base import DBTestCase
import database
import student_service as ss


class DatabaseTests(DBTestCase):
    def test_tables_exist(self):
        with database.get_conn() as c:
            names = {r["name"] for r in c.rows("SELECT name FROM sqlite_master WHERE type='table'")}
        for t in ("users", "students", "face_embeddings", "attendance", "audit_logs"):
            self.assertIn(t, names)

    def test_register_student_ok(self):
        sid = self.new_student()
        self.assertEqual(ss.get_student(sid)["roll_no"], "CE001")

    def test_duplicate_roll_rejected(self):
        self.new_student()
        with self.assertRaises(ValueError):
            self.new_student(name="Other")

    def test_consent_required(self):
        with self.assertRaises(ValueError):
            ss.add_student(self.teacher, "CE002", "X", "TE-A", "CE", consent=False)

    def test_invalid_roll_rejected(self):
        with self.assertRaises(ValueError):
            ss.add_student(self.teacher, "bad roll!", "X", "TE-A", "CE", consent=True)

    def test_foreign_key_enforced(self):
        with self.assertRaises(database.IntegrityViolation):
            with database.get_conn() as c:
                c.execute("INSERT INTO attendance (student_id, attendance_date, attendance_time, status, method, created_at)"
                          " VALUES (999,'2025-01-01','10:00:00','Present','face','x')")

    def test_delete_student_removes_everything(self):
        import numpy as np, attendance_service as att
        sid = self.new_student()
        ss.add_face(self.teacher, sid, np.ones(512, dtype=np.float32))
        att.mark_attendance(sid)
        ss.delete_student(self.admin, sid)
        with database.get_conn() as c:
            self.assertEqual(c.one("SELECT COUNT(*) n FROM face_embeddings")["n"], 0)
            self.assertEqual(c.one("SELECT COUNT(*) n FROM attendance")["n"], 0)


if __name__ == "__main__":
    unittest.main()
