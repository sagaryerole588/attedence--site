import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config  # noqa: E402
import database  # noqa: E402
import auth  # noqa: E402


class DBTestCase(unittest.TestCase):
    """Every test gets a brand-new temporary SQLite database."""

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        config.DATABASE_URL = f"sqlite:///{Path(self._tmp.name) / 'test.db'}"
        database.init_db()
        self.admin = {"id": auth.create_user("admin", "AdminPass123", "admin"), "username": "admin", "role": "admin"}
        self.teacher = {"id": auth.create_user("teach", "TeacherPass1", "teacher"), "username": "teach", "role": "teacher"}

    def tearDown(self):
        self._tmp.cleanup()

    def new_student(self, roll="CE001", name="Asha Rao"):
        import student_service as ss
        return ss.add_student(self.teacher, roll, name, "TE-A", "Computer Engineering", consent=True)
