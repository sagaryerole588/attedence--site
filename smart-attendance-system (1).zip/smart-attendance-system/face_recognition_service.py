"""Face detection + embedding extraction (pretrained DeepFace model) and matching.

Terminology (useful for the viva):
- Detection    : find WHERE a face is in the image (OpenCV detector).
- Alignment    : rotate/crop the face so eyes are level.
- Embedding    : a 512-number vector (Facenet512) describing the face.
- Verification : are these TWO faces the same person? (distance < threshold)
- Recognition  : WHO is this? (compare against all registered embeddings)

No model is trained here: we only run inference with a pretrained network.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

import config


@dataclass
class EmbeddingResult:
    status: str  # ok | no_face | multiple_faces | face_too_small | error
    message: str
    embedding: np.ndarray | None = None
    face_count: int = 0


@dataclass
class MatchResult:
    status: str  # matched | unknown | ambiguous | empty_gallery
    message: str
    student_id: int | None = None
    distance: float | None = None
    second_distance: float | None = None


# ---------- embedding storage (optionally encrypted) ----------
def serialize_embedding(vec: np.ndarray) -> bytes:
    raw = np.asarray(vec, dtype=np.float32).tobytes()
    if config.EMBEDDING_KEY:
        from cryptography.fernet import Fernet

        return b"E" + Fernet(config.EMBEDDING_KEY.encode()).encrypt(raw)
    return b"P" + raw


def deserialize_embedding(blob: bytes) -> np.ndarray:
    blob = bytes(blob)
    tag, payload = blob[:1], blob[1:]
    if tag == b"E":
        if not config.EMBEDDING_KEY:
            raise RuntimeError("Embeddings are encrypted but EMBEDDING_KEY is not set.")
        from cryptography.fernet import Fernet

        payload = Fernet(config.EMBEDDING_KEY.encode()).decrypt(payload)
    return np.frombuffer(payload, dtype=np.float32).copy()


# ---------- model inference ----------
def extract_embedding(image_bgr: np.ndarray) -> EmbeddingResult:
    """Detect, align and embed. Rejects images with zero or several faces."""
    try:
        from deepface import DeepFace
    except Exception as exc:  # TensorFlow/DeepFace not installed
        return EmbeddingResult("error", f"Face model could not be loaded: {exc}")
    try:
        results = DeepFace.represent(
            img_path=image_bgr,
            model_name=config.MODEL_NAME,
            detector_backend=config.DETECTOR_BACKEND,
            enforce_detection=True,
            align=True,
        )
    except ValueError:
        return EmbeddingResult("no_face", "No face detected. Face the camera, keep good lighting.")
    except Exception as exc:
        return EmbeddingResult("error", f"Face processing failed: {exc}")

    if len(results) == 0:
        return EmbeddingResult("no_face", "No face detected.")
    if len(results) > 1:
        return EmbeddingResult("multiple_faces", "More than one face detected. Only one person may be in the frame.",
                               face_count=len(results))
    area = results[0].get("facial_area", {})
    if min(area.get("w", 999), area.get("h", 999)) < config.MIN_FACE_PIXELS:
        return EmbeddingResult("face_too_small", "Face is too small. Move closer to the camera.", face_count=1)
    return EmbeddingResult("ok", "Face detected.", np.asarray(results[0]["embedding"], dtype=np.float32), 1)


# ---------- matching (pure NumPy: fully unit-testable) ----------
def cosine_distance(a: np.ndarray, b: np.ndarray) -> float:
    a, b = np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64)
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    if denom == 0:
        return 1.0
    return float(1.0 - np.dot(a, b) / denom)


def find_match(query: np.ndarray, gallery: list[tuple[int, np.ndarray]],
               threshold: float | None = None, margin: float | None = None) -> MatchResult:
    """1-to-N search. A student's score is the MIN distance over his/her samples."""
    threshold = config.DISTANCE_THRESHOLD if threshold is None else threshold
    margin = config.AMBIGUITY_MARGIN if margin is None else margin
    if not gallery:
        return MatchResult("empty_gallery", "No registered faces yet. Ask the teacher to register students.")

    best: dict[int, float] = {}
    for sid, vec in gallery:
        d = cosine_distance(query, vec)
        if sid not in best or d < best[sid]:
            best[sid] = d
    ranked = sorted(best.items(), key=lambda kv: kv[1])
    sid1, d1 = ranked[0]
    d2 = ranked[1][1] if len(ranked) > 1 else None

    if d1 > threshold:
        return MatchResult("unknown", "Face not recognized. Try again or ask the teacher for manual attendance.",
                           distance=d1, second_distance=d2)
    if d2 is not None and d2 <= threshold and (d2 - d1) < margin:
        return MatchResult("ambiguous", "Face is similar to more than one student. Attendance NOT marked; ask the teacher.",
                           distance=d1, second_distance=d2)
    return MatchResult("matched", "Face recognized.", sid1, d1, d2)
