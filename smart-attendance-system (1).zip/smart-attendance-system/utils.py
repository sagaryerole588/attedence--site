"""Validation and image helpers."""
from __future__ import annotations

import io
import re
from datetime import datetime
from zoneinfo import ZoneInfo

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

import config


class ImageValidationError(ValueError):
    """Raised with a user-friendly message when an image cannot be used."""


def now_local() -> datetime:
    try:
        return datetime.now(ZoneInfo(config.TIMEZONE))
    except Exception:
        return datetime.now()


def today_str() -> str:
    return now_local().strftime("%Y-%m-%d")


_ROLL_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9\-_/]{0,29}$")


def validate_roll_no(roll_no: str) -> str:
    roll_no = (roll_no or "").strip().upper()
    if not _ROLL_RE.match(roll_no):
        raise ValueError("Roll number must be 1-30 characters: letters, digits, '-', '_' or '/'.")
    return roll_no


def clean_text(value: str, field: str, max_len: int = 80, required: bool = True) -> str:
    value = re.sub(r"\s+", " ", (value or "")).strip()
    if required and not value:
        raise ValueError(f"{field} is required.")
    if len(value) > max_len:
        raise ValueError(f"{field} must be at most {max_len} characters.")
    return value


def validate_email(value: str) -> str:
    value = (value or "").strip()
    if value and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", value):
        raise ValueError("Email address looks invalid.")
    return value


def safe_filename(name: str) -> str:
    """Only letters, digits, dot, dash, underscore - safe for downloads."""
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", name or "file").strip("._")
    return name[:80] or "file"


def check_extension(filename: str) -> None:
    ext = (filename or "").rsplit(".", 1)[-1].lower()
    if ext not in config.ALLOWED_EXTENSIONS:
        raise ImageValidationError("Unsupported file type. Use JPG, PNG or WEBP.")


def load_image(data: bytes, filename: str | None = None) -> np.ndarray:
    """Validate raw bytes and return a BGR uint8 array (OpenCV convention)."""
    if filename:
        check_extension(filename)
    if not data:
        raise ImageValidationError("No image received.")
    if len(data) > config.MAX_UPLOAD_BYTES:
        raise ImageValidationError("Image is larger than 5 MB.")
    try:
        Image.open(io.BytesIO(data)).verify()
        img = Image.open(io.BytesIO(data))
        img = ImageOps.exif_transpose(img).convert("RGB")
    except (UnidentifiedImageError, OSError, SyntaxError):
        raise ImageValidationError("This file is not a valid image.") from None
    w, h = img.size
    if min(w, h) < config.MIN_IMAGE_SIDE:
        raise ImageValidationError(f"Image is too small (minimum {config.MIN_IMAGE_SIDE}px on each side).")
    longest = max(w, h)
    if longest > config.MAX_IMAGE_SIDE:
        scale = config.MAX_IMAGE_SIDE / longest
        img = img.resize((int(w * scale), int(h * scale)))
    return np.asarray(img)[:, :, ::-1].copy()


def check_quality(bgr: np.ndarray) -> None:
    """Reject images that are too dark, too bright or blurry."""
    import cv2

    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    brightness = float(gray.mean())
    if brightness < config.MIN_BRIGHTNESS:
        raise ImageValidationError("Image is too dark. Move to a brighter place and face the light.")
    if brightness > config.MAX_BRIGHTNESS:
        raise ImageValidationError("Image is too bright / overexposed. Avoid strong light behind or on the face.")
    if float(cv2.Laplacian(gray, cv2.CV_64F).var()) < config.MIN_SHARPNESS:
        raise ImageValidationError("Image is blurry. Hold the camera steady and try again.")
