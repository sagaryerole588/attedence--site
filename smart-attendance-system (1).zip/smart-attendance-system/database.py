"""Database layer. Works with SQLite (local) and PostgreSQL (online) using
plain DB-API connections, so there is no ORM to learn for the viva."""
from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime

import config


class IntegrityViolation(Exception):
    """Raised when a UNIQUE / FOREIGN KEY / CHECK constraint fails."""


def is_postgres() -> bool:
    return config.DATABASE_URL.startswith("postgresql")


_SCHEMA = [
    """CREATE TABLE IF NOT EXISTS users (
        id {PK},
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        full_name TEXT,
        role TEXT NOT NULL CHECK (role IN ('admin','teacher')),
        is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
        created_at TEXT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS students (
        id {PK},
        roll_no TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        class_name TEXT NOT NULL,
        department TEXT NOT NULL,
        email TEXT,
        phone TEXT,
        is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
        consent_given INTEGER NOT NULL DEFAULT 0 CHECK (consent_given IN (0,1)),
        consent_at TEXT,
        created_at TEXT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS face_embeddings (
        id {PK},
        student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
        embedding {BLOB} NOT NULL,
        model_name TEXT NOT NULL,
        created_at TEXT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS attendance (
        id {PK},
        student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
        attendance_date TEXT NOT NULL,
        attendance_time TEXT NOT NULL,
        session_id TEXT NOT NULL DEFAULT 'DAILY',
        status TEXT NOT NULL CHECK (status IN ('Present','Absent')),
        method TEXT NOT NULL CHECK (method IN ('face','manual')),
        marked_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
        created_at TEXT NOT NULL,
        UNIQUE (student_id, attendance_date, session_id)
    )""",
    """CREATE TABLE IF NOT EXISTS audit_logs (
        id {PK},
        user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        username TEXT,
        action TEXT NOT NULL,
        target TEXT,
        details TEXT,
        created_at TEXT NOT NULL
    )""",
    "CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance (attendance_date)",
    "CREATE INDEX IF NOT EXISTS idx_embeddings_student ON face_embeddings (student_id)",
    "CREATE INDEX IF NOT EXISTS idx_students_class ON students (class_name, department)",
]


def now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class Conn:
    """Thin wrapper: '?' placeholders everywhere, dict rows, uniform errors."""

    def __init__(self, raw, pg: bool, integrity_errors: tuple):
        self.raw, self.pg, self._errors = raw, pg, integrity_errors

    def _cursor(self):
        if self.pg:
            import psycopg2.extras

            return self.raw.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        return self.raw.cursor()

    def execute(self, sql: str, params: tuple = ()):
        cur = self._cursor()
        try:
            cur.execute(sql.replace("?", "%s") if self.pg else sql, params)
        except self._errors as exc:
            raise IntegrityViolation(str(exc)) from exc
        return cur

    def rows(self, sql: str, params: tuple = ()) -> list[dict]:
        out = []
        for row in self.execute(sql, params).fetchall():
            d = dict(row)
            for k, v in d.items():
                if isinstance(v, memoryview):
                    d[k] = bytes(v)
            out.append(d)
        return out

    def one(self, sql: str, params: tuple = ()) -> dict | None:
        rows = self.rows(sql, params)
        return rows[0] if rows else None

    def insert(self, sql: str, params: tuple = ()) -> int:
        if self.pg:
            return self.execute(sql + " RETURNING id", params).fetchone()["id"]
        return self.execute(sql, params).lastrowid


@contextmanager
def get_conn():
    if is_postgres():
        import psycopg2

        raw = psycopg2.connect(config.DATABASE_URL)
        conn = Conn(raw, True, (psycopg2.IntegrityError,))
    else:
        path = config.sqlite_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        raw = sqlite3.connect(path)
        raw.row_factory = sqlite3.Row
        raw.execute("PRAGMA foreign_keys = ON")
        conn = Conn(raw, False, (sqlite3.IntegrityError,))
    try:
        yield conn
        raw.commit()
    except Exception:
        raw.rollback()
        raise
    finally:
        raw.close()


def init_db() -> None:
    """Create all tables/indexes (safe to run many times)."""
    pk = "SERIAL PRIMARY KEY" if is_postgres() else "INTEGER PRIMARY KEY AUTOINCREMENT"
    blob = "BYTEA" if is_postgres() else "BLOB"
    with get_conn() as conn:
        for stmt in _SCHEMA:
            conn.execute(stmt.replace("{PK}", pk).replace("{BLOB}", blob))


def log_action(conn: Conn, actor: dict | None, action: str, target: str = "", details: str = "") -> None:
    conn.execute(
        "INSERT INTO audit_logs (user_id, username, action, target, details, created_at) VALUES (?,?,?,?,?,?)",
        (actor.get("id") if actor else None, actor.get("username") if actor else "system",
         action, target, details, now_iso()),
    )
