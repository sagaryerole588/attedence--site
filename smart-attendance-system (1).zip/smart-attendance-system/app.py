"""Smart Attendance System - home page. Run with:  streamlit run app.py"""
import streamlit as st

import config
import ui

ui.setup_page("Home")
ui.hero(f"🎓 {config.APP_NAME}",
        "Face-recognition based attendance using OpenCV + DeepFace (pretrained FaceNet512)")

c1, c2 = st.columns(2)
with c1:
    st.markdown("### 👩‍🎓 For students")
    st.write("Open **Student Attendance** in the sidebar, look at the camera (or upload a photo) and your "
             "attendance is recorded after a confident match.")
with c2:
    st.markdown("### 👨‍🏫 For teachers / admins")
    st.write("Log in from the sidebar, then use **Admin Dashboard**, **Student Management** and "
             "**Attendance Reports**.")

st.markdown("### How it works")
st.markdown(
    "1. Capture image → 2. Validate (size, light, blur) → 3. Detect & align face → "
    "4. Create 512-number embedding (pretrained model) → 5. Compare with registered embeddings → "
    "6. Apply distance threshold, reject unknown/ambiguous → 7. Check duplicate → 8. Save date & time."
)
st.warning(
    "⚠️ Face recognition can make **false matches or misses**. This system has **no liveness detection / "
    "anti-spoofing**: a printed photo or a screen may fool it. Teachers can always mark attendance manually."
)
st.info("Face data is stored only as numeric embeddings (optionally encrypted), never as public images. "
        "Students must give consent and can ask for their data to be deleted.")
