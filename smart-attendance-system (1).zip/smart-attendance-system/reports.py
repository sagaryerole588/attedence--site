"""CSV / Excel export helpers."""
from __future__ import annotations

import io

import pandas as pd

import attendance_service as att
from utils import safe_filename


def to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8-sig")  # BOM so Excel opens it correctly


def to_excel_bytes(sheets: dict[str, pd.DataFrame]) -> bytes:
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as writer:
        for name, df in sheets.items():
            df.to_excel(writer, sheet_name=safe_filename(name)[:31] or "Sheet", index=False)
    return buf.getvalue()


def daily_report(date: str, class_name=None, department=None) -> dict[str, pd.DataFrame]:
    df = att.daily_status(date, class_name, department).drop(columns=["student_id"])
    return {"Daily": df}


def range_report(start: str, end: str, class_name=None, department=None) -> dict[str, pd.DataFrame]:
    return {
        "Records": att.attendance_records(start, end, class_name, department),
        "Percentages": att.student_percentages(start, end, class_name, department),
    }
