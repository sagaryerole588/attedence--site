"""Central configuration. Values come from environment variables, a local
.env file, or Streamlit secrets (for cloud deployment). No secrets are hardcoded."""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _get(name: str, default: str | None = None) -> str | None:
    value = os.getenv(name)
    if value:
        return value
    try:  # Streamlit Community Cloud secrets
        import streamlit as st

        if name in st.secrets:
            return str(st.secrets[name])
    except Exception:
        pass
    return default


def _float(name: str, default: float) -> float:
    try:
        return float(_get(name, str(default)))
    except (TypeError, ValueError):
        return default


def _normalize_db_url(url: str) -> str:
    if url.startswith("postgres://"):
        url = "postgresql://" + url[len("postgres://"):]
    return url


APP_NAME = "Smart Attendance System"
DATABASE_URL = _normalize_db_url(_get("DATABASE_URL", "sqlite:///data/attendance.db"))

ADMIN_USERNAME = _get("ADMIN_USERNAME")
ADMIN_PASSWORD = _get("ADMIN_PASSWORD")
ADMIN_FULL_NAME = _get("ADMIN_FULL_NAME", "Administrator")
EMBEDDING_KEY = _get("EMBEDDING_KEY")  # Fernet key; encrypts stored embeddings

MODEL_NAME = _get("MODEL_NAME", "Facenet512")
DETECTOR_BACKEND = _get("DETECTOR_BACKEND", "opencv")
DISTANCE_METRIC = "cosine"
# Facenet512 + cosine: DeepFace's published default is 0.30. It is only a
# STARTING POINT - validate it on your own genuine/impostor pairs (see README).
DISTANCE_THRESHOLD = _float("DISTANCE_THRESHOLD", 0.30)
# Best match must beat the runner-up by at least this much when both are close.
AMBIGUITY_MARGIN = _float("AMBIGUITY_MARGIN", 0.05)

TIMEZONE = _get("TIMEZONE", "Asia/Kolkata")
DEFAULT_SESSION = "DAILY"

MAX_UPLOAD_BYTES = 5 * 1024 * 1024
MIN_IMAGE_SIDE = 160
MAX_IMAGE_SIDE = 1280
MIN_BRIGHTNESS = 50.0
MAX_BRIGHTNESS = 215.0
MIN_SHARPNESS = 20.0
MIN_FACE_PIXELS = 80
ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "webp"}


def sqlite_path() -> Path:
    raw = DATABASE_URL[len("sqlite:///"):]
    path = Path(raw)
    return path if path.is_absolute() else BASE_DIR / path
