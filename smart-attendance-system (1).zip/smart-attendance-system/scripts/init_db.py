"""Create tables and (optionally) the first admin.
Usage:  python scripts/init_db.py
        python scripts/init_db.py --create-user teacher1 --role teacher   (asks for password)"""
import argparse
import getpass
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import auth  # noqa: E402
import config  # noqa: E402
import database  # noqa: E402

parser = argparse.ArgumentParser()
parser.add_argument("--create-user")
parser.add_argument("--role", default="teacher", choices=["admin", "teacher"])
args = parser.parse_args()

database.init_db()
print(f"Database ready: {'PostgreSQL' if database.is_postgres() else config.sqlite_path()}")
if auth.bootstrap_admin():
    print(f"Admin '{config.ADMIN_USERNAME}' created from .env")
if args.create_user:
    pw = getpass.getpass("Password (min 8 chars): ")
    auth.create_user(args.create_user, pw, args.role)
    print(f"User '{args.create_user}' ({args.role}) created.")
