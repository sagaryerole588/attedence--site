"""Pick a recognition threshold from YOUR data.

Folder layout (keep OUTSIDE git, it contains real faces):
    validation/
        alice/ 1.jpg 2.jpg 3.jpg
        bob/   1.jpg 2.jpg 3.jpg
        ...
Run:  python scripts/validate_threshold.py validation
It prints genuine-pair and impostor-pair distances and the best threshold."""
import itertools
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import face_recognition_service as frs  # noqa: E402
from utils import load_image  # noqa: E402

root = Path(sys.argv[1] if len(sys.argv) > 1 else "validation")
embs: dict[str, list[np.ndarray]] = {}
for person in sorted(p for p in root.iterdir() if p.is_dir()):
    for img in sorted(person.glob("*")):
        try:
            r = frs.extract_embedding(load_image(img.read_bytes(), img.name))
        except Exception as exc:
            print("skip", img, exc); continue
        if r.status == "ok":
            embs.setdefault(person.name, []).append(r.embedding)
        else:
            print("skip", img, r.message)

genuine, impostor = [], []
for name, vs in embs.items():
    genuine += [frs.cosine_distance(a, b) for a, b in itertools.combinations(vs, 2)]
for (n1, v1), (n2, v2) in itertools.combinations(embs.items(), 2):
    impostor += [frs.cosine_distance(a, b) for a in v1 for b in v2]

if not genuine or not impostor:
    sys.exit("Need at least 2 people with 2+ usable photos each.")
print(f"genuine pairs: {len(genuine)}  mean={np.mean(genuine):.3f} max={np.max(genuine):.3f}")
print(f"impostor pairs: {len(impostor)} mean={np.mean(impostor):.3f} min={np.min(impostor):.3f}")
print("\nthreshold  FAR(false accept)  FRR(false reject)")
best = None
for t in np.arange(0.10, 0.80, 0.05):
    far = float(np.mean(np.array(impostor) <= t)); frr = float(np.mean(np.array(genuine) > t))
    print(f"{t:8.2f}  {far:16.1%}  {frr:16.1%}")
    if far == 0 and (best is None or frr < best[1]):
        best = (t, frr)
print("\nSuggested DISTANCE_THRESHOLD (zero false accepts, lowest false rejects):",
      f"{best[0]:.2f}" if best else "none - collect better photos")
