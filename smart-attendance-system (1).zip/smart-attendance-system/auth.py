"""Authentication (scrypt password hashing) and role-based authorization."""
from __future__ import annotations

import hashlib
import hmac
import os

import config
import database

PERMISSIONS = {
    "admin": {"*"},
    "teacher": {
        "view_reports", "manage_students", "register_face",
        "mark_attendance", "correct_attendance",
    },
}
ADMIN_ONLY = {"delete_student", "manage_users", "view_audit_log"}

_N, _R, _P = 2 ** 14, 8, 1


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=_N, r=_R, p=_P)
    return f"scrypt${_N}${_R}${_P}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, n, r, p, salt, digest = stored.split("$")
        calc = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=int(n), r=int(r), p=int(p))
        return hmac.compare_digest(calc, bytes.fromhex(digest))
    except Exception:
        return False


def can(user: dict | None, action: str) -> bool:
    if not user or user.get("role") not in PERMISSIONS:
        return False
    perms = PERMISSIONS[user["role"]]
    if action in ADMIN_ONLY:
        return user["role"] == "admin"
    return "*" in perms or action in perms


def ensure_permission(user: dict | None, action: str) -> None:
    """Server-side check used by every service function that changes data."""
    if not can(user, action):
        raise PermissionError(f"You are not allowed to perform: {action}")


def create_user(username: str, password: str, role: str = "teacher", full_name: str = "") -> int:
    username = (username or "").strip().lower()
    if not username or len(password or "") < 8:
        raise ValueError("Username required and password must be at least 8 characters.")
    if role not in ("admin", "teacher"):
        raise ValueError("Role must be 'admin' or 'teacher'.")
    with database.get_conn() as conn:
        try:
            return conn.insert(
                "INSERT INTO users (username, password_hash, full_name, role, created_at) VALUES (?,?,?,?,?)",
                (username, hash_password(password), full_name, role, database.now_iso()),
            )
        except database.IntegrityViolation:
            raise ValueError("That username already exists.") from None


def authenticate(username: str, password: str) -> dict | None:
    with database.get_conn() as conn:
        row = conn.one("SELECT * FROM users WHERE username = ?", ((username or "").strip().lower(),))
        if not row or not row["is_active"] or not verify_password(password or "", row["password_hash"]):
            database.log_action(conn, None, "login_failed", target=(username or "")[:50])
            return None
        user = {"id": row["id"], "username": row["username"], "role": row["role"], "full_name": row["full_name"]}
        database.log_action(conn, user, "login")
        return user


def bootstrap_admin() -> bool:
    """Create the first admin from ADMIN_USERNAME / ADMIN_PASSWORD if no user exists."""
    with database.get_conn() as conn:
        if conn.one("SELECT id FROM users LIMIT 1"):
            return False
    if config.ADMIN_USERNAME and config.ADMIN_PASSWORD:
        create_user(config.ADMIN_USERNAME, config.ADMIN_PASSWORD, "admin", config.ADMIN_FULL_NAME or "")
        return True
    return False
