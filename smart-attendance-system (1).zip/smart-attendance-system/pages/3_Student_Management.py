import streamlit as st

import face_recognition_service as frs
import student_service as ss
import ui
from utils import ImageValidationError, check_quality, load_image

ui.setup_page("Student Management", "🧑‍🎓")
user = ui.require_login("manage_students")
ui.hero("🧑‍🎓 Student Management", "Register students and their face samples")

tab_add, tab_list = st.tabs(["➕ Add student", "📋 Students"])


def embed_images(items):
    """items: list of (bytes, filename). Returns embeddings; raises ValueError with a clear message."""
    out = []
    for i, (data, name) in enumerate(items, 1):
        try:
            bgr = load_image(data, name)
            check_quality(bgr)
        except ImageValidationError as exc:
            raise ValueError(f"Image {i}: {exc}") from None
        res = frs.extract_embedding(bgr)
        if res.status != "ok":
            raise ValueError(f"Image {i}: {res.message}")
        out.append(res.embedding)
    return out


with tab_add:
    n = st.session_state.get("form_n", 0)  # changing the key clears the form after success
    c1, c2 = st.columns(2)
    roll = c1.text_input("Roll number *", key=f"roll{n}")
    name = c2.text_input("Full name *", key=f"name{n}")
    cls = c1.text_input("Class *", placeholder="e.g. TE-A", key=f"cls{n}")
    dept = c2.text_input("Department *", value="Computer Engineering", key=f"dept{n}")
    email = c1.text_input("Email (optional)", key=f"mail{n}")
    phone = c2.text_input("Phone (optional)", key=f"ph{n}")
    st.markdown("**Face samples** - add 1 to 3 clear, front-facing photos (different light/expressions help).")
    cam = st.camera_input("Capture with camera", key=f"cam{n}")
    ups = st.file_uploader("...or upload photos", type=["jpg", "jpeg", "png", "webp"],
                           accept_multiple_files=True, key=f"up{n}")
    consent = st.checkbox("The student has given consent to store their facial data (embeddings) for attendance.",
                          key=f"consent{n}")
    if st.button("Save student", type="primary"):
        items = ([(cam.getvalue(), None)] if cam else []) + [(u.getvalue(), u.name) for u in (ups or [])[:3]]
        try:
            if not items:
                raise ValueError("Add at least one face photo.")
            with st.spinner("Checking faces..."):
                embeddings = embed_images(items)
            sid = ss.add_student(user, roll, name, cls, dept, email, phone, consent)
            for e in embeddings:
                ss.add_face(user, sid, e)
            st.success(f"Student registered with {len(embeddings)} face sample(s).")
            st.session_state["form_n"] = n + 1
            st.rerun()
        except (ValueError, PermissionError) as exc:
            st.error(str(exc))

with tab_list:
    search = st.text_input("Search name or roll number")
    df = ss.list_students(search)
    st.dataframe(df.drop(columns=["email", "phone"]), use_container_width=True, hide_index=True)
    if df.empty:
        st.info("No students yet.")
    else:
        st.markdown("#### Edit / manage a student")
        options = {f"{r.roll_no} - {r.name}": int(r.id) for r in df.itertuples()}
        label = st.selectbox("Select student", list(options))
        sid = options[label]
        stu = ss.get_student(sid)
        e1, e2 = st.columns(2)
        new_name = e1.text_input("Name", stu["name"], key=f"en{sid}")
        new_cls = e2.text_input("Class", stu["class_name"], key=f"ec{sid}")
        new_dep = e1.text_input("Department", stu["department"], key=f"ed{sid}")
        new_mail = e2.text_input("Email", stu["email"] or "", key=f"em{sid}")
        new_ph = e1.text_input("Phone", stu["phone"] or "", key=f"ep{sid}")
        if st.button("Save changes"):
            try:
                ss.update_student(user, sid, new_name, new_cls, new_dep, new_mail, new_ph)
                st.success("Updated."); st.rerun()
            except (ValueError, PermissionError) as exc:
                st.error(str(exc))

        a, b, c = st.columns(3)
        if a.button("Deactivate" if stu["is_active"] else "Activate"):
            ss.set_active(user, sid, not stu["is_active"]); st.rerun()
        if b.button("Delete face data"):
            ss.delete_faces(user, sid); st.success("Face data deleted."); st.rerun()
        with c:
            if user["role"] == "admin":
                confirm = st.checkbox("Confirm permanent delete (student + face data + attendance)", key=f"cf{sid}")
                if st.button("🗑️ Delete student", disabled=not confirm):
                    ss.delete_student(user, sid); st.success("Deleted."); st.rerun()
            else:
                st.caption("Only admins can delete students.")

        st.markdown("#### Add more face samples")
        more = st.camera_input("Capture another sample", key=f"morecam{sid}")
        if more and st.button("Add this sample"):
            try:
                emb = embed_images([(more.getvalue(), None)])[0]
                ss.add_face(user, sid, emb); st.success("Sample added.")
            except (ValueError, PermissionError) as exc:
                st.error(str(exc))
