import datetime as dt

import streamlit as st

import attendance_service as att
import auth
import reports
import student_service as ss
import ui
from utils import now_local

ui.setup_page("Attendance Reports", "📑")
user = ui.require_login("view_reports")
ui.hero("📑 Attendance Reports", "Search, filter, download and correct attendance")

today = now_local().date()
c1, c2, c3 = st.columns(3)
start = c1.date_input("From", today - dt.timedelta(days=7), max_value=today)
end = c2.date_input("To", today, max_value=today)
cls = c3.selectbox("Class", [""] + ss.distinct_values("class_name")) or None
d1, d2 = st.columns(2)
dep = d1.selectbox("Department", [""] + ss.distinct_values("department")) or None
search = d2.text_input("Search name / roll number")
if start > end:
    st.error("'From' date must not be after 'To' date.")
    st.stop()
s, e = start.isoformat(), end.isoformat()

tabs = ["Records", "Daily status", "Percentages", "Manual / correction"] + (["Audit log"] if auth.can(user, "view_audit_log") else [])
t = st.tabs(tabs)

with t[0]:
    df = att.attendance_records(s, e, cls, dep, search)
    st.dataframe(df, use_container_width=True, hide_index=True)
    sheets = reports.range_report(s, e, cls, dep)
    a, b = st.columns(2)
    a.download_button("⬇️ CSV", reports.to_csv_bytes(df), f"attendance_{s}_to_{e}.csv", "text/csv", use_container_width=True)
    b.download_button("⬇️ Excel", reports.to_excel_bytes(sheets), f"attendance_{s}_to_{e}.xlsx",
                      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)

with t[1]:
    day = st.date_input("Day", today, max_value=today, key="daydate")
    daily = att.daily_status(day.isoformat(), cls, dep, search).drop(columns=["student_id"])
    st.dataframe(daily, use_container_width=True, hide_index=True)
    a, b = st.columns(2)
    a.download_button("⬇️ Daily CSV", reports.to_csv_bytes(daily), f"daily_{day}.csv", "text/csv", use_container_width=True)
    b.download_button("⬇️ Daily Excel", reports.to_excel_bytes({"Daily": daily}), f"daily_{day}.xlsx",
                      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)

with t[2]:
    pct = att.student_percentages(s, e, cls, dep)
    st.caption("Percentage = days present ÷ sessions held (days with any attendance record) in the date range.")
    st.dataframe(pct, use_container_width=True, hide_index=True)
    st.download_button("⬇️ Percentages CSV", reports.to_csv_bytes(pct), f"percentages_{s}_to_{e}.csv", "text/csv")

with t[3]:
    st.markdown("Use for students whose face was not recognized, or to fix a mistake. Every change is logged with your name.")
    students = ss.list_students(include_inactive=False)
    if students.empty:
        st.info("No active students.")
    else:
        opts = {f"{r.roll_no} - {r.name}": int(r.id) for r in students.itertuples()}
        who = st.selectbox("Student", list(opts))
        mday = st.date_input("Date", today, max_value=today, key="mdate")
        mstatus = st.radio("Status", ["Present", "Absent"], horizontal=True)
        reason = st.text_input("Reason (required)")
        if st.button("Save attendance", type="primary"):
            try:
                msg = att.correct_attendance(user, opts[who], mday.isoformat(), mstatus, reason)
                st.success(f"Saved ({msg}).")
            except (ValueError, PermissionError) as exc:
                st.error(str(exc))

if "Audit log" in tabs:
    with t[4]:
        st.dataframe(att.audit_log(), use_container_width=True, hide_index=True)
