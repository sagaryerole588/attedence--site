import streamlit as st

import attendance_service as att
import ui

ui.setup_page("Student Attendance", "📷")
ui.hero("📷 Student Attendance", "Look at the camera or upload a clear photo of your face")
st.caption("Only ONE person in the frame • face the light • remove mask/sunglasses • hold the phone steady")

tab_cam, tab_up = st.tabs(["📷 Use camera", "🖼️ Upload photo"])
image_bytes, filename = None, None
with tab_cam:
    shot = st.camera_input("Take a photo", help="Allow camera permission in your browser.")
    if shot:
        image_bytes, filename = shot.getvalue(), None
with tab_up:
    up = st.file_uploader("Choose a face photo", type=["jpg", "jpeg", "png", "webp"])
    if up:
        image_bytes, filename = up.getvalue(), up.name
        st.image(image_bytes, width=240)

if image_bytes and st.button("✅ Mark my attendance", type="primary", use_container_width=True):
    with st.spinner("Detecting and recognizing face... (first run loads the model and can take a minute)"):
        result = att.process_attendance_image(image_bytes, filename)
    level, msg = result["level"], result["message"]
    student = result.get("student")
    if student:
        st.markdown(f"### {student['name']}  \nRoll No: **{student['roll_no']}** · {student['class_name']} · {student['department']}")
    {"success": st.success, "info": st.info, "warning": st.warning, "error": st.error}[level](msg)
    if level == "success":
        st.balloons()
    if result.get("distance") is not None:
        with st.expander("Technical details (for demo)"):
            st.write(f"Cosine distance: **{result['distance']:.3f}** (lower = more similar)")

st.divider()
st.caption("Not recognized or camera not working? Ask your teacher to mark attendance manually.")
