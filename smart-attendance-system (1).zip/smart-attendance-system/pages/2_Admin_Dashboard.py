import datetime as dt

import streamlit as st

import attendance_service as att
import student_service as ss
import ui
from utils import now_local, today_str

ui.setup_page("Admin Dashboard", "📊")
ui.require_login("view_reports")
ui.hero("📊 Admin Dashboard", "Overview of today's attendance")

classes = [""] + ss.distinct_values("class_name")
depts = [""] + ss.distinct_values("department")
f1, f2, f3 = st.columns(3)
day = f1.date_input("Date", now_local().date(), max_value=now_local().date())
cls = f2.selectbox("Class", classes) or None
dep = f3.selectbox("Department", depts) or None

s = att.daily_summary(day.isoformat(), cls, dep)
m1, m2, m3, m4 = st.columns(4)
m1.metric("Registered students", s["total"])
m2.metric("Present", s["present"])
m3.metric("Absent", s["absent"])
m4.metric("Attendance %", f"{s['percent']}%")

st.subheader("Date-wise attendance (last 14 days)")
end = now_local().date()
series = att.date_series((end - dt.timedelta(days=13)).isoformat(), end.isoformat(), cls, dep)
if series.empty:
    st.info("No attendance data yet.")
else:
    st.bar_chart(series.set_index("date")["present"])

st.subheader("Recent attendance records")
recent = att.attendance_records((end - dt.timedelta(days=30)).isoformat(), end.isoformat(), cls, dep).head(15)
st.dataframe(recent, use_container_width=True, hide_index=True)

st.subheader(f"Absent on {day}")
status = att.daily_status(day.isoformat(), cls, dep)
st.dataframe(status[status["status"] == "Absent"][["roll_no", "name", "class_name", "department"]],
             use_container_width=True, hide_index=True)
