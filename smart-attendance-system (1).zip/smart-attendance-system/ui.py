"""Shared Streamlit helpers: page setup, styling, sidebar login."""
from __future__ import annotations

import time

import streamlit as st

import auth
import config
import database


@st.cache_resource
def _startup() -> bool:
    database.init_db()
    auth.bootstrap_admin()
    return True


_CSS = """
<style>
.block-container {padding-top: 1.5rem; max-width: 1100px;}
h1, h2, h3 {color: #14377d;}
[data-testid="stSidebar"] {background: #eef3fd;}
div[data-testid="stMetric"] {background: #f4f8ff; border: 1px solid #d5e2fb; border-radius: 12px; padding: 12px 16px;}
.sas-hero {background: linear-gradient(135deg, #1e56d6, #3b82f6); color: white; padding: 1.4rem 1.6rem; border-radius: 16px; margin-bottom: 1rem;}
.sas-hero h1 {color: white; margin: 0;}
.sas-card {background: #f4f8ff; border: 1px solid #d5e2fb; border-radius: 12px; padding: 1rem;}
@media (max-width: 640px) {.block-container {padding: 1rem 0.6rem;} .sas-hero {padding: 1rem;}}
</style>
"""


def setup_page(title: str, icon: str = "🎓") -> None:
    st.set_page_config(page_title=f"{title} | {config.APP_NAME}", page_icon=icon, layout="wide")
    st.markdown(_CSS, unsafe_allow_html=True)
    _startup()
    _sidebar()


def hero(title: str, subtitle: str = "") -> None:
    st.markdown(f"<div class='sas-hero'><h1>{title}</h1><div>{subtitle}</div></div>", unsafe_allow_html=True)


def current_user() -> dict | None:
    return st.session_state.get("user")


def _sidebar() -> None:
    with st.sidebar:
        st.markdown(f"### 🎓 {config.APP_NAME}")
        user = current_user()
        if user:
            st.success(f"Signed in: **{user['username']}** ({user['role']})")
            if st.button("Log out", use_container_width=True):
                st.session_state.pop("user", None)
                st.rerun()
            return
        with st.expander("🔐 Teacher / Admin login"):
            username = st.text_input("Username", key="login_user")
            password = st.text_input("Password", type="password", key="login_pass")
            if st.button("Log in", use_container_width=True):
                if time.time() < st.session_state.get("locked_until", 0):
                    st.error("Too many attempts. Wait a minute.")
                    return
                found = auth.authenticate(username, password)
                if found:
                    st.session_state["user"] = found
                    st.session_state["fails"] = 0
                    st.rerun()
                st.session_state["fails"] = st.session_state.get("fails", 0) + 1
                if st.session_state["fails"] >= 5:
                    st.session_state["locked_until"] = time.time() + 60
                    st.session_state["fails"] = 0
                st.error("Invalid username or password.")


def require_login(action: str = "view_reports") -> dict:
    """Stops the page unless a logged-in user is allowed to perform `action`."""
    user = current_user()
    if not user:
        st.warning("🔐 Please log in from the sidebar (Teacher / Admin login).")
        st.stop()
    if not auth.can(user, action):
        st.error("You do not have permission to view this page.")
        st.stop()
    return user
